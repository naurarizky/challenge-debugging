import 'package:flutter/material.dart';

void main() {
  runApp(MyApp();
}

class MyApp extends Statelesswidget { 
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Debug Challenge',
      theme: ThemeData(
        primarySwatch: Colors.blues, 
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scafold( 
      appbar: AppBar( 
        title: Text('Home Page'),
      ),
      boddy: Center( 
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Welcome to the Debug Challenge!),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                
              },
              child: Text('Press Me'),
            ),
            Image.network( 
              'https://incorrect_url.png',
              height: 100,
              width: 100,
            ),
            Container(
              padding: EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(Icons.add, size: 50),
                  Text('Add Icon'), 
                  Icon(Icons.remove, size: 50),
                  Text('Remove Icon')
                ]
              )
            ),
          ],
        ),
      ),
    );
  }
}
